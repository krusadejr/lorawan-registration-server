# Generated common code
